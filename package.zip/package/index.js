export function add(a, b) {
  return a + b;
}

export function divide(a, b) {
  return a / b;
}