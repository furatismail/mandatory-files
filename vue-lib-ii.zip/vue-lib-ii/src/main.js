export { default as VButton } from "./components/VButton/VButton.vue";

// import VButton from "./components/VButton/VButton.vue";
// export { VButton };
